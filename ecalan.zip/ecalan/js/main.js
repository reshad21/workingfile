let downloadbar=document.querySelector('#downloadbar');
let downloadchart=document.querySelector('#downloadchart');

downloadbar.addEventListener('click',function(e){
	e.preventDefault();

	if(downloadbar.value==="yes"){
		downloadchart.style.display="none";
		downloadbar.value="no";
	}
	else{
		downloadchart.style.display="block";
		downloadbar.value="yes";
	}
});


// naveber script
let showhidebar=document.getElementById('showhidebar');
let navbermenu=document.getElementById('navbermenu');

showhidebar.addEventListener('click',function(e){
	e.preventDefault();

	if (showhidebar.value=="yes") {
		navbermenu.style.display="none";
		navbermenu.style.width="0";
		// navbermenu.style.marginTop="20px";
		showhidebar.value="no";
	}
	else{
		navbermenu.style.display="block";
		navbermenu.style.width="100%";
		showhidebar.value="yes";
	}
});
