# Nivo Slider

The Nivo Slider is world renowned as the most beautiful and easy to use image slider on the market. There is literally no better way to make your website look totally stunning.

See http://dev7studios.com/plugins/nivo-slider for more info.

Docs: http://docs.dev7studios.com/jquery-plugins/nivo-slider
